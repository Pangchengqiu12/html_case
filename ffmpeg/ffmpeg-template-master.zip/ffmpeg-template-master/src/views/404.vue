<template>
  <div class="page-404-wrap">
    <el-empty image-size="10vw" description="404" />
  </div>
</template>

<style lang="scss">
.page-404-wrap {
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #fff;
  height: 100vh;
}
</style>
